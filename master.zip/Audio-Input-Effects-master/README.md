# Live Audio Input effects

I whipped this app up to test live audio input, letting the user select a few common tunable effects and see (and hear) the effects.  It's also a good demo of how to build chorus and flanging effects in WebAudio.

Check it out, feel free to fork, submit pull requests, etc.

-Chris