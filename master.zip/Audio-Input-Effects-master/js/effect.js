function Effect() {
	this.controls = [];
	this.input = null;
	this.output = null;
}

Effect.prototype.addLinearControls = function( params, name, min, max, step, initial ) {
//	[leftDelay.delayTime, rightDelay.delayTime], "Delay", 0.01, 2.0, 0.01, delayTime )


}

function EffectControl(type, min, max, initial, values) {

}